import { App } from 'vue';
import FloatingVue from 'floating-vue';

type FloatingVueConfig = Parameters<(typeof FloatingVue)['install']>[1];
declare function enhanceTwoslash(app: App): void;

export { type FloatingVueConfig, enhanceTwoslash };
