declare function useCollapsedLines({ selector, }?: {
    selector?: string;
}): void;

export { useCollapsedLines };
