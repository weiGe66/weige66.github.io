interface CopyCodeOptions {
    selector?: string;
    duration?: number;
}
declare function useCopyCode({ selector, duration, }?: CopyCodeOptions): void;

export { useCopyCode };
