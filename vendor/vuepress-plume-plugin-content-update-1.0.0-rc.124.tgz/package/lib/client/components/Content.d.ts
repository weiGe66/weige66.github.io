import * as vue from 'vue';

/**
 * Markdown rendered content
 */
declare const Content: vue.DefineComponent<vue.ExtractPropTypes<{
    path: {
        type: StringConstructor;
        required: false;
        default: string;
    };
}>, () => vue.VNode<vue.RendererNode, vue.RendererElement, {
    [key: string]: any;
}>, {}, {}, {}, vue.ComponentOptionsMixin, vue.ComponentOptionsMixin, {}, string, vue.PublicProps, Readonly<vue.ExtractPropTypes<{
    path: {
        type: StringConstructor;
        required: false;
        default: string;
    };
}>> & Readonly<{}>, {
    path: string;
}, {}, {}, {}, string, vue.ComponentProvideOptions, true, {}, any>;

export { Content };
