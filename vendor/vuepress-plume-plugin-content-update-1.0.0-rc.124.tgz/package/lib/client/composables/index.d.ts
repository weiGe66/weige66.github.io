interface ContentUpdated {
    mounted?: boolean;
    updated?: boolean;
    beforeUnmount?: boolean;
}
/**
 * Register callback that is called every time the markdown content is updated
 * in the DOM.
 */
declare function onContentUpdated(fn: () => any): void;
declare function runCallbacks(lifeCircleType: ContentUpdated): void;

export { type ContentUpdated, onContentUpdated, runCallbacks };
