import { Plugin } from 'vuepress/core';

declare function contentUpdatePlugin(): Plugin;

export { contentUpdatePlugin, contentUpdatePlugin as default };
